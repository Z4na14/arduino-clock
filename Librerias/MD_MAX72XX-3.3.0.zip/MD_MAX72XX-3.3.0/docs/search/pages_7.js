var searchData=
[
  ['parola_20custom_20module_224',['Parola Custom Module',['../page_parola.html',1,'pageHardware']]]
];
